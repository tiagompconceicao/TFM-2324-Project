package pt.isel.tfm.tc.backend.project

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
